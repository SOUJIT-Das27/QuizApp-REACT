import React,{useState} from 'react';
import axios from 'axios';
export default function Check(){
    const [data,setData]=useState([])
    axios.get("https://opentdb.com/api.php?amount=10&category=26&difficulty=easy&type=multiple")
    
    .then((res)=>{
        setData(res.data.results);
    })
    .catch(err=>console.log(err));
    console.log(data);

    return (
    <>
        <h1>HI</h1>
    </>)
}