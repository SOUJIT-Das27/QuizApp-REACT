import React from 'react';
import Logo from "../../../assets/HomePage/quizlogo.png";
import style from "./HomeNav.module.css";
export default function HomeNav(){
    return (
        <>
            <nav className={style.nav_container}>
            <a href="/" className={style.nav_logo}>
                <img src={Logo}/><span>Mindiser</span>
            </a>
            <div className={style.nav_menu}>
               <ul className={style.nav_list}>
                  <li className={style.nav_item}>
                     <a href="/menu" className={style.nav_link}>Menu</a>
                  </li>
                  <li className={style.nav_item}>
                  <a href="/quiz" className={style.nav_link}>Quiz</a>
                  </li>
                  <li className={style.nav_item}>
                     <a href="/about" className={style.nav_link}>About</a>
                  </li>
                  <li className={style.nav_item}>
                     <a href="/contact" className={style.nav_link}>Contact Us</a>
                  </li> 
               </ul>
               <div className={style.nav_sign}>
               <a href="/sign" className={style.nav_button}>
                  Login
               </a>
               <a href="/sign" className={`${style.nav_button} ${style.sign}`}>
                  Sign Up
               </a>
            </div>
            </div>
         </nav>
        </>
    )
}