import React,{useLayoutEffect,useRef} from "react";
import gsap from "gsap";

import homePoints from "../../assets/HomePage/points-space.svg";
import planet from "../../assets/HomePage/planet.svg";
import rocket from "../../assets/HomePage/rocket.svg";
import homeCloud1 from "../../assets/HomePage/clouds-1.svg";
import homeCloud2 from "../../assets/HomePage/clouds-2.svg";
import textLine from "../../assets/HomePage/line.svg";


import style from './Home.module.css';
import HomeNav from "./NavHome/HomeNav";


export default function Home(){
    const comp=useRef();

    useLayoutEffect(()=>{
        let ctx = gsap.context(()=>{
            const t1 = gsap.timeline();
            t1.from('.Home_home_points__Kk6WU',1.5,{opacity:0 , y:-300, delay:0})
            .from('.Home_home_rocket__DlALd',1.5,{opacity:0 , y: 300, delay:-1.5})
            .from('.Home_home_planet_1__bXiZY',1.5,{opacity:0 , y:-200, delay:-1.2})
                .from('.Home_home_planet_2__-AXqy',1.5,{opacity:0 , y: 200, delay:-1.2})
                .from('.Home_home_cloud_1__rPocN',1.5,{opacity:0 , y: 200, delay:-1.2})
                .from('.Home_home_cloud_2__Rhc4M',1.5,{opacity:0 , x: 200, delay:-1.2})
                .from('.Home_home_content__CnB22',1.5,{opacity:0 , y: -100, delay:-1.2})
                .from('.Home_home_title__o31Ro img',1.5,{opacity:0 , x: 100, delay:-1.2})
        },comp);

        return ()=> ctx.revert()
    },[])
    return (
        <>
            <div className={style.body}>
            <header className={style.header}>
               <HomeNav/>
            </header>

      <main className={style.main}>
         <section className={style.home} ref={comp}>
            <div className={style.home_container}>
                  <div className={style.home_content}>
                     <h3 className={style.home_subtitle}>
                        EXPLORE THE UNIVERSE
                     </h3>
                  <h1 className={style.home_title}>
                     <span>
                        Start Exploring<br/>
                        All over the World
                     </span>
                     <img src={textLine} alt="image"/>
                  </h1>
                  <p className={style.home_description}>
                     Start to Explore in the World and discover wonders in TRIVIA mode.
                  </p>
                  <a href="/sign" className={style.home_button}>
                     Get Started
                  </a>
               </div>
               <div className={style.home_images}>
                  <img src={homePoints} alt="image" className={style.home_points}/>
                  <img src={planet} alt="image" className={style.home_planet_2}/>
                  <img src={planet} alt="image" className={style.home_planet_1}/>
                  <img src={rocket} alt="image" className={style.home_rocket}/>
               </div>
            </div>
            <img src={homeCloud1} alt="image" className={style.home_cloud_1}/>
            <img src={homeCloud2} alt="image" className={style.home_cloud_2}/>
         </section>
      </main>
      </div>
        </>
    );
}