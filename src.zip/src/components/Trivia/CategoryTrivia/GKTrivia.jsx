import React from 'react';
import { gk } from "../../../assets/data.js";
import Trivia from "../Trivia.jsx";

export default function GKTrivia(){
    return(
        <Trivia data={gk}/>
    );
}