import React from 'react';
import { art } from "../../../assets/data.js";
import Trivia from "../Trivia.jsx";

export default function ArtTrivia(){
    return(
        <Trivia data={art}/>
    );
}