import React from 'react';
import { sports } from "../../../assets/data.js";
import Trivia from "../Trivia.jsx";

export default function SportsTrivia(){
    return(
        <Trivia data={sports} ic="uil uil-basketball"/>
    );
}