import React from 'react';
import { gadgets} from "../../../assets/data.js";
import Trivia from "../Trivia.jsx";

export default function GadgetsTrivia(){
    return(
        <Trivia data={gadgets}/>
    );
}