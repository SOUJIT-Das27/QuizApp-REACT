import React from 'react';
import { celebrity} from "../../../assets/data.js";
import Trivia from "../Trivia.jsx";

export default function CelebrityTrivia(){
    return(
        <Trivia data={celebrity}/>
    );
}