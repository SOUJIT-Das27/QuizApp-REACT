import React from 'react';
import { math } from "../../../assets/data.js";
import Trivia from "../Trivia.jsx";

export default function MathTrivia(){
    return(
        <Trivia data={math}/>
    );
}