import React from 'react';
import { geography } from "../../../assets/data.js";
import Trivia from "../Trivia.jsx";

export default function GeoTrivia(){
    return(
        <Trivia data={geography}/>
    );
}