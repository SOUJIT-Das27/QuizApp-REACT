import React from 'react';
import { music } from "../../../assets/data.js";
import Trivia from "../Trivia.jsx";

export default function MusicTrivia(){
    return(
        <Trivia data={music}/>
    );
}