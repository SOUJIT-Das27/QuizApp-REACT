import React from 'react';
import { politics } from "../../../assets/data.js";
import Trivia from "../Trivia.jsx";

export default function PoliticsTrivia(){
    return(
        <Trivia data={politics}/>
    );
}