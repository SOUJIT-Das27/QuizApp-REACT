import React from 'react';
import { cartoon } from "../../../assets/data.js";
import Trivia from "../Trivia.jsx";

export default function CartoonTrivia(){
    return(
        <Trivia data={cartoon}/>
    );
}