import React from 'react';
import { history } from "../../../assets/data.js";
import Trivia from "../Trivia.jsx";

export default function HistoryTrivia(){
    return(
        <Trivia data={history}/>
    );
}