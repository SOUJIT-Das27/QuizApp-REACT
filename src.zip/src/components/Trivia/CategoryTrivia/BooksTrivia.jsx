import React from 'react';
import { books } from "../../../assets/data.js";
import Trivia from "../Trivia.jsx";

export default function BooksTrivia(){
    return(
        <Trivia data={books}/>
    );
}