import React from 'react';
import { mythology } from "../../../assets/data.js";
import Trivia from "../Trivia.jsx";

export default function MythologyTrivia(){
    return(
        <Trivia data={mythology}/>
    );
}