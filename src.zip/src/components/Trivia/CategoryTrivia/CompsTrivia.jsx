import React from 'react';
import { comp } from "../../../assets/data.js";
import Trivia from "../Trivia.jsx";

export default function CompsTrivia(){
    return(
        <Trivia data={comp}/>
    );
}