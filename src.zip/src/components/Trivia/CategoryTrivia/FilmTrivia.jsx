import React from 'react';
import { film } from "../../../assets/data.js";
import Trivia from "../Trivia.jsx";

export default function FilmTrivia(){
    return(
        <Trivia data={film}/>
    );
}