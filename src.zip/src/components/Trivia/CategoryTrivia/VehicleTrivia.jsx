import React from 'react';
import { vehicles } from "../../../assets/data.js";
import Trivia from "../Trivia.jsx";

export default function VehicleTrivia(){
    return(
        <Trivia data={vehicles}/>
    );
}