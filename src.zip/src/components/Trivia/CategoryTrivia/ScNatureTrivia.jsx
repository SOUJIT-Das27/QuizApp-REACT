import React from 'react';
import { scnature } from "../../../assets/data.js";
import Trivia from "../Trivia.jsx";

export default function ScNatureTrivia(){
    return(
        <Trivia data={scnature}/>
    );
}