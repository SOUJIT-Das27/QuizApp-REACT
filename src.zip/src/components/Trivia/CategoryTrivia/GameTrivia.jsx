import React from 'react';
import { games } from "../../../assets/data.js";
import Trivia from "../Trivia.jsx";

export default function GameTrivia(){
    return(
        <Trivia data={games}/>
    );
}