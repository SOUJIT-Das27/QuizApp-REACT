import React,{useState,useRef} from 'react';
import Logo from "../../assets/HomePage/quizlogo.png";
import styles from './Trivia.module.css';
import './correct.css';
import axios from 'axios';

export default function Quiz({data,ic}){

  axios.get('https://opentdb.com/api.php?amount=5&category=27&difficulty=hard&type=multiple')
.then((res)=>{
  let datas=[]
  for(let i=0;i<5;i++){
  let rand=Math.floor(Math.random()*4);
  res.data.results[i].incorrect_answers.splice(rand,0,res.data.results[i].correct_answer);
  }
  for(let i of res.data.results){
    datas.push(i);
  }
  
})
.catch(err=>console.log("Error: "+err));
  let [index,setIndex] = useState(0);
  const [question,setQuestion] = useState(data[index]);
  const [lock,setLock] = useState(false);
  const [score,setScore]=useState(0);
  const [result,setResult]= useState(false);
     
    let Option1 = useRef();
    let Option2 = useRef();
    let Option3 = useRef();
    let Option4 = useRef();

    let option_array = [Option1,Option2,Option3,Option4];

    const checkAns = (e,ans) => {
      if(lock === false){
            if(question.correct_answer===ans){
                e.target.classList.add("correct");
                setLock(true);
                setScore(orev=>orev+1);
            }else{
                e.target.classList.add("wrong");
                setLock(true);
                option_array[question.incorrect_answers.indexOf(question.correct_answer)].current.classList.add("correct");
            }
    }
  }

  const reset=()=>{
    setIndex(0);
    setQuestion(data[0]);
    setScore(0);
    setLock(false);
    setResult(false);
  }
    
    const next = () => {
        if(lock===true){
          if(index === data.length-1){
            setResult(true);
            return 0;
          }
            setIndex(++index);
            setQuestion(data[index]);
            setLock(false);
            option_array.map((option)=>{
              option.current.classList.remove("wrong");
              option.current.classList.remove("correct");
              return null;
            })
        }
    }
    return (
        <div className={styles.body}>
        <div className={styles.container}>
            <div className={styles.head}><img className={styles.photo} src={Logo}/><h1>Mindiser</h1>
            <span><i className={`${styles.icon} ${ic}`}></i></span>
            </div>
            <br/><br/>
            {
            result?<></>:
            <>
            <h2><span className={styles.qno}>{index+1}.  </span>{question.question}</h2>
            <ul>
                <li ref={Option1} onClick={(e)=>{checkAns(e,question.incorrect_answers[0])}}>{question.incorrect_answers[0]}</li>
                <li ref={Option2} onClick={(e)=>{checkAns(e,question.incorrect_answers[1])}}>{question.incorrect_answers[1]}</li>
                <li ref={Option3} onClick={(e)=>{checkAns(e,question.incorrect_answers[2])}}>{question.incorrect_answers[2]}</li>
                <li ref={Option4} onClick={(e)=>{checkAns(e,question.incorrect_answers[3])}}>{question.incorrect_answers[3]}</li>
            </ul>
            <button onClick={next}>Next</button>
            <div className={styles.index}>
                {index+1} of {data.length} questions
            </div>
            </>
            }
            {result?<><h2>You Scored {score} out of {data.length}</h2>
            <button onClick={reset}>Reset</button></>:<></>}   
        </div>
        </div>
    )
}