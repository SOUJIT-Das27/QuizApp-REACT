import React from 'react';
import styles from "./Team.module.css";
export default function Team({photo,name,role}){
    return (
        <article className={styles.team_member}>
                <div className={styles.team_member_image}>
                    <img src={photo}/>
                </div>
                <div className={styles.team_member_info}>
                    <h4>{name}</h4>
                    <p>{role}</p>
                </div>
                <div className={styles.team_member_socials}>
                    <a href="https://instagram.com" target="blank"><i className="uil uil-instagram"></i></a>
                    <a href="https://x.com" target="blank"><i className="uil uil-twitter-alt"></i></a>
                    <a href="https://linkedin.com" target="blank"><i className="uil uil-linkedin-alt"></i></a>
                </div>
            </article>
    )
}