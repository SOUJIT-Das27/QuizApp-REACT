import React from 'react';
import styles from "./Achive.module.css"
export default function Achivements({count,type,icon}){
    return (
        <article className={styles.achivement_card}>
                        <span className={styles.achivement_icon}>
                            <i className={icon}></i>
                        </span>
                        <h3>{count}</h3>
                        <p>{type}</p>
                    </article>
    )
}