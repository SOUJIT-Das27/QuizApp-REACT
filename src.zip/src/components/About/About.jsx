import React from 'react';
import hero from "../../assets/About/about achievements.svg";
import profile1 from "../../assets/About/soujit.png"
import profile2 from "../../assets/About/suvhadra.jpg"
import profile3 from "../../assets/About/sharmistha.png"
import profile4 from "../../assets/About/sraboni.png"
import profile5 from "../../assets/About/arindita.jpeg"
import styles from"./About.module.css"
import Achivements from './Others/Achievements';
import Footer from '../Universal/Footer';
import Team from './Others/Team';
import NavBar from '../Universal/NavBar';


export default function About(){
    return (
        <div className={styles.body}>
        <NavBar/>
      <section className={styles.about_achievements}>
        <div className={`${styles.container} ${styles.about_achivements_container}`}>
            <div className={styles.about_achivements_left}>
                <img src={hero}/>
            </div>
            <div className={styles.about_achivements_right}>
                <h1>Achievements</h1>
                <p>Our quiz app has achieved remarkable milestones, reflecting our commitment to providing an engaging and educational experience for users. Since its launch, the app has garnered over 80,000 traffic and boasts a robust user base that actively participates in daily quizzes. We are proud to have maintained an average rating of 4.8 stars on major app platforms, highlighting user satisfaction and positive feedback.</p>
                <div className={styles.achivements_cards}>
                    <Achivements count="450+" type="Quiz Questions" icon="uil uil-comment-question"/>
                    <Achivements count="79,000+" type="Audience" icon="uil uil-users-alt"/>
                    <Achivements count="26+" type="Awards" icon="uil uil-trophy"/>
                </div>
            </div>
        </div>
      </section>

      <section className={styles.team}>
        <h2>Meet Our Team</h2>
        <div className={`${styles.container} ${styles.team_container}`}>
            <Team photo={profile1} name="Soujit Das" role="Software Developer"/>
            <Team photo={profile2} name="Suvhadra Bardhan" role="Web Developer"/>
            <Team photo={profile3} name="Sharmistha Das" role="Web Developer"/>
            <Team photo={profile4} name="Sraboni Baidya" role="Web Developer"/>
            <Team photo={profile5} name="Arindita Poddar" role="Web Developer"/>
        </div>
      </section>
      <Footer/>
        </div>
    )
}