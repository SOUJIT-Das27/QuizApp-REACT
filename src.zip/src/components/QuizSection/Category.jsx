import React from "react";
import styles from "./Category.module.css";

export default function Category(props) {
  return (
    <>  
          <article class={styles.quiz}>
            <div class={styles.quiz_image}>
              <img src={props.photo} class={styles.quiz_image} alt="image" />
            </div>
            <div class={styles.quiz_info}>
              <h4>{props.title}</h4>
              <p>
                {props.details}
              </p>
              <a href={props.url} class={`${styles.btn} ${styles.btn_primary}`}>
                Start Quiz
              </a>
            </div>
          </article>
        
    </>
  );
}
