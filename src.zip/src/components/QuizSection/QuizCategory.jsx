import React from "react";
import Category from "./Category"
import sports from "../../assets/QCat/sportsQuiz.jpg"
import books from "../../assets/QCat/bookQuiz.png"
import music from "../../assets/QCat/musicQuiz.jpg"
import film from "../../assets/QCat/movie-slate-film.jpg"
import art from "../../assets/QCat/13.png"
import cartoon from "../../assets/QCat/csdrr.jpg"
import celebrity from "../../assets/QCat/download.jpg"
import coms from "../../assets/QCat/ComputerScience.jpg"
import gadgets from "../../assets/QCat/Best-Gadgets-for.jpg"
import game from "../../assets/QCat/1711718371905.jpg"
import geo from "../../assets/QCat/geography.jpg"
import gk from "../../assets/QCat/General-Knowledge.jpg"
import history from "../../assets/QCat/Battle-of-New.jpg"
import math from "../../assets/QCat/360_F_134dfd.jpg"
import myth from "../../assets/QCat/mythology.png"
import politics from "../../assets/QCat/BPAC_Main.png"
import nature from "../../assets/QCat/nat.jpg"
import vehicle from "../../assets/QCat/audi.jpg"




import styles from "./QuizCategory.module.css";
import NavBar from "../Universal/NavBar";
import Footer from "../Universal/Footer";
export default function QuizCategory() {
  let sp="Our sports quiz challenges your knowledge across a wide range of sports, from football to basketball.For sports enthusiasts,Perfect for fans looking to test their skills and learn fun facts about their favorite games."
  let fi="Our film quiz is ideal for movie buffs, challenging your knowledge of classic films, modern blockbusters, actors, and directors. Test your cinematic expertise with questions of genres and eras.challenging your knowledge of classic films"
  let ar="Our art quiz invites art lovers to test their knowledge on famous paintings, artists, and art movements. Challenge yourself with questions about masterpieces from different periods and styles. Perfect for those passionate about art history and visual culture."
  let cartoo="Our cartoon quiz is a delightful journey through beloved animated worlds, testing your knowledge of iconic characters, series, and animation studios.Perfect for cartoon enthusiasts of all ages, it's a fun way to reminisce and showcase your cartoon IQ!"
  let bk="Our books quiz is perfect for avid readers and literature enthusiasts, testing your knowledge on classic novels, contemporary bestsellers, and everything in between. Challenge yourself with questions about authors, plots, and literary genres."
  let mus="Our music quiz is designed for music lovers, testing your knowledge across genres, artists, and iconic songs. see how you know the most about rock, pop, classical, and more.Perfect for those who live and breathe music."
  let celeb="Our celebrity quiz is for pop culture aficionados, challenging your knowledge of Hollywood stars, musicians, and public figures.Perfect for fans who love keeping up with the latest buzz and want to prove they're the ultimate celebrity expert!"
  let cs="Our computer science quiz is a comprehensive exploration of coding languages, algorithms, and tech history, perfect for aspiring programmers and tech enthusiasts.  Whether you're a novice or an expert, this quiz is a great way to deepen your understanding of the digital world."
  let gadg="Our gadgets quiz is a thrilling journey through the world of technology, From smartphones and wearables to smart home devices, dive into the realm of cutting-edge tech and test your expertise. This quiz is sure to entertain and educate!"
  let vigm="Our video game quiz immerses players in the thrilling world of gaming, testing their knowledge of beloved characters, and gaming history.Perfect for gamers of all levels, it's a fun way to reminisce about gaming memories and showcase your gaming IQ!"
  let geogr="Our geography quiz is an exciting exploration of the world's continents, countries, landmarks, and cultures, perfect for globe-trotters and map enthusiasts. from around the globe.This quiz is a captivating journey of discovery!"
  let genk="Our general knowledge quiz is to Challenge yourself with a diverse range of questions designed to entertain and educate, perfect for trivia enthusiast.Enjoy a fun mental workout, this quiz is sure to keep you engaged and informed!"
  let hist="Our history quiz takes you on an immersive journey of human civilization, testing your knowledge of significant events, figures, and eras.It's a captivating exploration of the past that will enrich your understanding of the world."
  let mathem="Our math quiz is a stimulating challenge for number enthusiasts, testing your skills in arithmetic, algebra, geometry, and beyond. Whether you're a math whiz or looking to sharpen your skills, this quiz offers an engaging way."
  let mytho="Our mythology quiz delves into the rich tapestry of ancient myths and legends. From Greek and Norse mythology to Egyptian and Hindu tales, explore epic stories and legendary figures as you answer questions spanning various mythological traditions."
  let pol="Our politics quiz is a thought-provoking exploration of the complex world of governance, elections, and global affairs, perfect for politically-minded individuals.Political systems, leaders, and current events as you navigate through a diverse range of questions. "
  let natur="Our science and nature quiz is an immersive journey into the wonders of the natural world,biology, astronomy and more. Explore the mysteries of the universe, from the depths of the ocean to the far reaches of outer space, and scientific discoveries. "
  let vehic="Our vehicle quiz is an exciting exploration of the world of transportation, testing your knowledge of cars, motorcycles, planes, and more. From classic automobiles to cutting-edge technology, challenge yourself with questions about iconic vehicles, manufacturers, and historical milestones."
  return (
    <>
    <div className={styles.body}>
      <NavBar/>
      
      <section class={styles.quiz}>
      <h1 style={{textAlign:"center"}}>Explore Quiz Categories</h1><br/>
        <div class={`${styles.container} ${styles.quiz_container}`}>
        
            <Category photo={sports} url="/trivia/sports" details={sp} title="Sports"/>
            <Category photo={books} url="/trivia/books" details={bk} title="Books"/>
            <Category photo={music} url="/trivia/music" details={mus} title="Music"/>
            <Category photo={film} url="/trivia/film" details={fi} title="Films"/>
            <Category photo={art} url="/trivia/art" details={ar} title="Art"/>
            <Category photo={cartoon} url="/trivia/cartoon" details={cartoo} title="Cartoon"/>
            <Category photo={celebrity} url="/trivia/celebrity" details={celeb} title="Celebrity"/>
            <Category photo={coms} url="/trivia/comps" details={cs} title="Computer Science"/>
            <Category photo={gadgets} url="/trivia/gadgets" details={gadg} title="Gadgets"/>
            <Category photo={game} url="/trivia/game" details={vigm} title="Video Games"/>
            <Category photo={geo} url="/trivia/geography" details={geogr} title="Geography"/>
            <Category photo={gk} url="/trivia/generalknowledge" details={genk} title="General Knowledge"/>
            <Category photo={history} url="/trivia/history" details={hist} title="History"/>
            <Category photo={math} url="/trivia/math" details={mathem} title="Mathematics"/>
            <Category photo={myth} url="/trivia/mythology" details={mytho} title="Mythology"/>
            <Category photo={politics} url="/trivia/politics" details={pol} title="Politics"/>
            <Category photo={nature} url="/trivia/nature" details={natur} title="Nature"/>
            <Category photo={vehicle} url="/trivia/vehicle" details={vehic} title="Vehicle"/>
        </div>
      </section>
      <Footer/>
      </div>
    </>
  );
}
