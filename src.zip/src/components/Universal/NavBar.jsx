import React from 'react';
import Logo from "../../assets/HomePage/quizlogo.png";
import styles from './NavBar.module.css';

export default function NavBar(){
  window.addEventListener('scroll',()=>{
    document.querySelector('nav').classList.toggle('NavBar_window_scroll__3aRoz',window.scrollY>0);
});
    return (
        <nav className={styles.nav}>
        <div className={`${styles.container} ${styles.nav_container}`}>
        <a href="/" className={styles.nav_logo}>
                <img src={Logo}/><span>Mindiser</span>
            </a>
          <ul className={styles.nav_menu}>
            <li><a href="/menu">Menu</a></li>
            <li><a href="/quiz">Quiz</a></li>
            <li><a href="/about">About</a></li>
            <li><a href="/contact">Contact Us</a></li>
          </ul>
          <button id="open-menu-btn"><i class="uil uil-bars"></i></button>
          <button id="open-menu-btn"><i class="uil uil-multiply"></i></button>
        </div>
      </nav>
    );
}