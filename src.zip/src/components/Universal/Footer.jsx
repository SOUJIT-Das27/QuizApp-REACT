import React from 'react';
import styles from "./Footer.module.css";
export default function Footer(){
    return(
        <>
            <footer className={styles.footer}>
        <div className={`${styles.container} ${styles.footer_container}`}>
            <div className={styles.footer_1}>
                <a href="/" className="footer-logo"><h4>Mindiser</h4></a>
                <p>Our quiz app offers a fun and engaging way to test your knowledge across various topics, So Have Fun!
                </p>
            </div>

            <div className={styles.footer_2}>
                <h4>Permalinks</h4>
                <ul className="permalinks">
                    <li><a href="/">Home</a></li>
                    <li><a href="/quiz">Quiz</a></li>
                    <li><a href="/about">About</a></li>
                    <li><a href="/contact">Contact</a></li>
                </ul>
            </div>

            <div className={styles.footer_3}>
                <h4>Privacy</h4>
                <ul className="privacy">
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Terms and conditions</a></li>
                    <li><a href="#">Quizzes</a></li>
                    <li><a href="/contact">Contact</a></li>
                </ul>
            </div>

            <div className={styles.footer_4}>
                <h4>Contact Us</h4>
                <div>
                    <p>+91 8420133252</p>
                    <p>soujitdas1999@gmail.com</p>
                </div>

                <ul className={styles.footer_socials}>
                    <li><a href="#"><i className="uil uil-facebook-f"></i></a></li>
                    <li><a href="#"><i className="uil uil-instagram-alt"></i></a></li>
                    <li><a href="#"><i className="uil uil-twitter"></i></a></li>
                    <li><a href="#"><i className="uil uil-linkedin-alt"></i></a></li>
                </ul>
            </div>
        </div>
        <div className={styles.footer_copyright}>
            <small>Copyright &copy; Mindiser</small>
        </div>
    </footer>
        </>
    )
}