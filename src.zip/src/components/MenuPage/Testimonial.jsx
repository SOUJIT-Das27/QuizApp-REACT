import React from 'react';
import styles from "./Testimonial.module.css"
export default function Testimonial({photo,name,identity,comment}){
    return (
        <article className={`${styles.testimonial} swiper-slide`}>
            <div className={styles.avatar}>
                <img src={photo}/>
            </div>
            <div className={styles.testimonial_info}>
                <h5>{name}</h5>
                <small>{identity}</small>
            </div>
            <div className={styles.testimonial_body}>
                <p>"{comment}"</p>
        </div>
        </article>
    )
}