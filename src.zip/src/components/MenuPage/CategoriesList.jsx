import React from 'react';
import styles from "./CategoriesList.module.css";



export default function CategoriesList({icon,role,details}){
    return (
        <article className={styles.category}>
                    <span className={styles.category_icon}>
                        <i className={icon}></i>
                    </span>
                    <h5>{role}</h5>
                    <p>{details}</p>
        </article>
    )
}