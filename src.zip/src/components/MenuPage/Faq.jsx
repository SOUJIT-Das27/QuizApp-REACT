import React from 'react';
import styles from './Faq.module.css';
export default function Faq({question,answer}){
    const faqs= document.querySelectorAll('.Faq_faq_icon__uzxZD');
    return (
        <article className={styles.faq}>
                <div className={styles.faq_icon}><i className="uil uil-plus"></i></div>
                <div className={styles.question_answer}>
                    <h4>{question}</h4>
                    <p>{answer}
                    </p>
                </div>
            </article>
    )
}