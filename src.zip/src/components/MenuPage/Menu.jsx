import React from "react";

import header from "../../assets/MenuPage/13379598_5210980-removebg-preview.png";
import sports from "../../assets/QCat/sportsQuiz.jpg"
import books from "../../assets/QCat/bookQuiz.png"
import music from "../../assets/QCat/musicQuiz.jpg"

import avatar1 from "../../assets/MenuPage/avatar1.jpg";
import avatar2 from "../../assets/MenuPage/avatar2.jpg";
import avatar3 from "../../assets/MenuPage/avatar3.jpg";
import avatar4 from "../../assets/MenuPage/avatar4.jpg";
import avatar5 from "../../assets/MenuPage/avatar5.jpg";
import avatar6 from "../../assets/MenuPage/avatar6.jpg";

import styles from './Menu.module.css';


import NavBar from "../Universal/NavBar";
import Footer from "../Universal/Footer";
import Category from "../QuizSection/Category";
import Faq from "./Faq";
import Testimonial from "./Testimonial";
import CategoriesList from "./CategoriesList";


export default function Menu(){
    
    let sp="Our sports quiz challenges your knowledge across a wide range of sports, from football to basketball.For sports enthusiasts,Perfect for fans looking to test their skills and learn fun facts about their favorite games.";
    let bk="Our books quiz is perfect for avid readers and literature enthusiasts, testing your knowledge on classic novels, contemporary bestsellers, and everything in between. Challenge yourself with questions about authors, plots, and literary genres.";
  let mus="Our music quiz is designed for music lovers, testing your knowledge across genres, artists, and iconic songs. see how you know the most about rock, pop, classical, and more.Perfect for those who live and breathe music.";
        let p1="Sports quiz challenges your knowledge of athletes, teams, and sporting events across various disciplines and competitions."
        let p2="Art quiz challenges your knowledge of famous artists, iconic artworks, and various art movements throughout history."
        let p3="Books quiz tests your knowledge of authors,literary works,and genres from classic literature to bestsellers."
        let p4="A computer science quiz tests your knowledge of programming, algorithms, data structures,and key technological concepts."
        let p5="Music quiz challenges your knowledge of songs, artists, and musical history across various genres and eras."
        let p6="Game quiz tests your knowledge of video games, including characters, and gaming history across various platforms and genres."
        let faq1="Are there rewards for playing quizzes?"
        let faq2="What happens if I don't know the answer to a question?"
        let faq3="Can I create my own quizzes on the app?"
        let faq4="How often are new quizzes added to the app?"
        let faq5="Is the app available on multiple platforms?"
        let faq6="How can I report a problem or suggest a new feature?"
        let faq7="How do I play a quiz on the app?"
        let faq8="Is it helpful for learnig new?";

        let faqA1="Not right now,we are working on that,Thanks for your feedback!";
        let faqA2="Don't worry! Our app will show the right answer after you choose one answer";
        let faqA3="Yes, our app provides a feature for users to create and share their own quizzes with the community."
        let faqA4="We regularly update our quiz database with fresh content to keep the experience exciting and engaging."
        let faqA5="Not right now,we are working on that,Thanks for your feedback!"
        let faqA6="We have Contact Us section to take your valuable feedback!"
        let faqA7="To play a quiz, simply open the app and navigate to the desired category and start answering the questions."
        let faqA8="Yes, Of Course! Test your knowledge and Have fun with the App.Thank You!"

        let feed1="Fun and addictive – can't stop playing!";
        let feed2="Love the variety of quiz categories!";
        let feed3="Challenging questions keep me on my toes.";
        let feed4="Great way to learn while having fun!";
        let feed5="Super easy to use and navigate through quizzes.";
        let feed6="A fantastic way to pass the time and learn new things.";
    return (
        <div className={styles.body}>
            <NavBar/>
    <header className={styles.header}>
        <div className={`${styles.container} ${styles.header_container}`}>
            <div className={styles.header_left}>
                <h1>
                Challenge Your Knowledge and Have Fun With Endless Quizzes!
                </h1><br/>
                <p>Discover What You Know, Challenge What You Don't! Dive into Endless Fun with Our Interactive Quizzes. Are You Ready to Test Your Knowledge?</p>
                <a href="/quiz" className={`${styles.btn} ${styles.btn_primary}`}>Go Explore!</a>
            </div>
            <div className={styles.header_right}>
                <img src={header} alt="image"/>
            </div>
        </div>
    </header>


    <section className={styles.categories}>
        <div className={`${styles.container} ${styles.categories_container}`}>
            <div className={styles.categories_left}>
                <h1>Categories</h1>
                <p>Dive into the world of literature with questions about classic novels, contemporary bestsellers, and famous authors.Test your sports knowledge across various disciplines, from football and basketball to tennis etc</p><br/>
                <a href="#" className={styles.btn}>Learn More</a>
            </div>

            <div className={styles.categories_right}>
                <CategoriesList icon="uil uil-basketball" role="Sports" details={p1}/>
                <CategoriesList icon="uil uil-palette" role="Art" details={p2}/>
                <CategoriesList icon="uil uil-book-open" role="Books" details={p3}/>
                <CategoriesList icon="uil uil-desktop" role="Computer Science" details={p4}/>
                <CategoriesList icon="uil uil-music" role="Music" details={p5}/>
                <CategoriesList icon="uil uil-puzzle-piece" role="Video Game" details={p6}/>
                
            </div>
        </div>
    </section>


    <section className={styles.quizzes}>
        <div className={`${styles.container} ${styles.quizzes_container}`}>
        <Category photo={sports} url="/trivia/sports" details={sp} title="Sports"/>
            <Category photo={books} url="/trivia/books" details={bk} title="Books"/>
            <Category photo={music} url="/trivia/music" details={mus} title="Music"/>
        </div>
    </section>

    <section className={styles.faqs}>
        <h2> Frequently Asked Questions</h2>
        <div className={`${styles.container} ${styles.faqs_container}`}>
            <Faq question={faq1} answer={faqA1}/>
            <Faq question={faq2} answer={faqA2}/>
            <Faq question={faq3} answer={faqA3}/>
            <Faq question={faq4} answer={faqA4}/>
            <Faq question={faq5} answer={faqA5}/>
            <Faq question={faq6} answer={faqA6}/>
            <Faq question={faq7} answer={faqA7}/>
            <Faq question={faq8} answer={faqA8}/>
        </div>
    </section>


    <section className={`${styles.container} ${styles.testimonials_container} mySwiper`}>
        <h2>Audience Testimonials</h2>
        <div className="swiper_wrapper">
                <Testimonial photo={avatar1} name="John Doh" identity="Footballer" comment={feed1}/>
                <Testimonial photo={avatar2} name="Brellie Wenst" identity="Gamer" comment={feed2}/>
                <Testimonial photo={avatar3} name="Abhishek Chowdhury" identity="Student" comment={feed3}/>
                <Testimonial photo={avatar4} name="Ream Malik" identity="Web Designer" comment={feed4}/>
                <Testimonial photo={avatar5} name="Emma Ortega" identity="Anonymous" comment={feed5}/>
                <Testimonial photo={avatar6} name="Sohie Turner" identity="Fashion Designer" comment={feed6}/>
        </div>
    </section>

    <Footer/>
        </div>
    )
}