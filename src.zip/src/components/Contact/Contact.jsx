import React from 'react';
import contact from "../../assets/Contact/contact.svg";
import styles from './Contact.module.css'
import NavBar from '../Universal/NavBar';
import Footer from '../Universal/Footer';
export default function Contact(){
    return (
        <>
        <div className={styles.body}>
        <NavBar/>
    
    <section className={styles.contact}>
        <div className={`${styles.container} ${styles.contact_container}`}>
            <aside className={styles.contact_aside}>
                <div className={styles.aside_image}>
                    <img src={contact}/>
                </div>
                <h2>Contact Us</h2>
                <p>
                &nbsp; &nbsp; &nbsp; &nbsp;Thank you! for taking the time to share your thoughts with us. Your feedback is incredibly valuable. We appreciate your input to making your experience even better.
                </p>
                <ul className={styles.contact_details}>
                    <li>
                        <i className="uil uil-phone-times"></i>
                        <h5>+91 7645829401</h5>
                    </li>
                    <li>
                        <span><i className="uil uil-envelope"></i></span>
                        <h5>support@mindiser.com</h5>
                    </li>
                    <li>
                        <i className="uil uil-location-point"></i>
                        <h5>Sector-V, SaltLake</h5>
                    </li>
                </ul>
                <ul className={styles.contact_socials}>
                    <li><a href="https://facebook.com" target="_balnk"><i className="uil uil-facebook-f"></i></a></li>
                    <li><a href="https://instagram.com" target="_balnk"><i className="uil uil-instagram"></i></a></li>
                    <li><a href="https://x.com"><i className="uil uil-twitter" target="_balnk"></i></a></li>
                    <li><a href="https://linkedin.com" target="_balnk"><i className="uil uil-linkedin-alt"></i></a></li>
                </ul>
            </aside>

            <form className={styles.contact_form} action="https://formspree.io/f/mzbnqlkn" method="POST">
                <div class={styles.form_name}>
                    <input type="text" name="First Name" placeholder="First Name" required/>
                    <input type="text" name="Last Name" placeholder="Last Name" required/>
                </div>
                <input type="email" name="Email Address" placeholder="Your email...."/>
                <textarea name="Message" rows="7" required></textarea>
                <button type="submit" className={`${styles.btn} ${styles.btn_primary}`}>Send Message</button>
            </form>
        </div>
    </section>
    <Footer/>
        </div>
        </>
    )
}