import React from 'react'
import { BrowserRouter,Route,Routes } from 'react-router-dom'
import Home from './components/HomePage/Home';
import QuizCategory from './components/QuizSection/QuizCategory';
import Menu from './components/MenuPage/Menu';
import About from './components/About/About';
import Contact from './components/Contact/Contact';
import LogSign from './components/LoginSignUp/LogSign'
import ArtTrivia from './components/Trivia/CategoryTrivia/ArtTrivia';
import BooksTrivia from './components/Trivia/CategoryTrivia/BooksTrivia';
import CartoonTrivia from './components/Trivia/CategoryTrivia/CartoonTrivia';
import CelebrityTrivia from './components/Trivia/CategoryTrivia/CelebrityTrivia';
import CompsTrivia from './components/Trivia/CategoryTrivia/CompsTrivia';
import FilmTrivia from './components/Trivia/CategoryTrivia/FilmTrivia';
import GadgetsTrivia from './components/Trivia/CategoryTrivia/GadgetsTrivia';
import GameTrivia from './components/Trivia/CategoryTrivia/GameTrivia';
import GeoTrivia from './components/Trivia/CategoryTrivia/GeoTrivia';
import GKTrivia from './components/Trivia/CategoryTrivia/GKTrivia';
import HistoryTrivia from './components/Trivia/CategoryTrivia/HistoryTrivia';
import MathTrivia from './components/Trivia/CategoryTrivia/MathTrivia';
import MusicTrivia from './components/Trivia/CategoryTrivia/MusicTrivia';
import MythologyTrivia from './components/Trivia/CategoryTrivia/MythologyTrivia';
import PoliticsTrivia from './components/Trivia/CategoryTrivia/PoliticsTrivia';
import ScNatureTrivia from './components/Trivia/CategoryTrivia/ScNatureTrivia';
import SportsTrivia from './components/Trivia/CategoryTrivia/SportsTrivia';
import VehicleTrivia from './components/Trivia/CategoryTrivia/VehicleTrivia';



function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route index element={<Home/>}/>
            <Route path="/" element={<Home/>}/>
            <Route path="/quiz" element={<QuizCategory/>}/>
            <Route path="/menu" element={<Menu/>}/>
            <Route path="/about" element={<About/>}/>
            <Route path="/sign" element={<LogSign/>}/>
            <Route path="/contact" element={<Contact/>}/>
            <Route path="/trivia/art" element={<ArtTrivia/>}/>
            <Route path="/trivia/books" element={<BooksTrivia/>}/>
            <Route path="/trivia/cartoon" element={<CartoonTrivia/>}/>
            <Route path="/trivia/celebrity" element={<CelebrityTrivia/>}/>
            <Route path="/strivia/comps" element={<CompsTrivia/>}/>
            <Route path="/trivia/film" element={<FilmTrivia/>}/>
            <Route path="/trivia/gadgets" element={<GadgetsTrivia/>}/>
            <Route path="/trivia/game" element={<GameTrivia/>}/>
            <Route path="/trivia/geography" element={<GeoTrivia/>}/>
            <Route path="/trivia/generalknowledge" element={<GKTrivia/>}/>
            <Route path="/trivia/history" element={<HistoryTrivia/>}/>
            <Route path="/trivia/math" element={<MathTrivia/>}/>
            <Route path="/trivia/music" element={<MusicTrivia/>}/>
            <Route path="/trivia/mythology" element={<MythologyTrivia/>}/>
            <Route path="/trivia/politics" element={<PoliticsTrivia/>}/>
            <Route path="/trivia/nature" element={<ScNatureTrivia/>}/>
            <Route path="/trivia/sports" element={<SportsTrivia/>}/>
            <Route path="/trivia/vehicle" element={<VehicleTrivia/>}/>
        </Routes>
    </BrowserRouter>
    </>
  );
}

export default App;
