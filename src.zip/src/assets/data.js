
export const sports=[
  {
    question: "What scientific suborder does the family Hyaenidae belong to?",
    correct_answer: "Feliformia",
    incorrect_answers: [
      "Haplorhini",
      "Feliformia",
      "Caniformia",
      "Ciconiiformes"
    ]
  },
  {
    question: "What national team won the 2016 edition of UEFA European Championship?",
    correct_answer: "Portugal",
    incorrect_answers: [
      "France",
      "Germany",
      "Portugal",
      "England"
    ]
  },
  {
    question: "What year was hockey legend Wayne Gretzky born?",
    correct_answer: "1961",
    incorrect_answers: [
      "1961",
      "1965",
      "1959",
      "1963"
    ]
  },
  {
    question: "Which soccer team won the Copa America Centenario 2016?",
    correct_answer: "Chile",
    incorrect_answers: [
      "Argentina",
      "Brazil",
      "Chile",
      "Colombia"
    ]
  },
    {
      question: "What is the full name of the footballer Cristiano Ronaldo?",
      correct_answer: "Cristiano Ronaldo dos Santos Aveiro",
      incorrect_answers: [
        "Cristiano Ronaldo los Santos Diego",
        "Cristiano Ronaldo dos Santos Aveiro",
        "Cristiano Armando Diego Ronaldo",
        "Cristiano Luis Armando Ronaldo"
      ]
    },
]


export const books=[
  {
    question: "By what name was the author Eric Blair better known?",
    correct_answer: "George Orwell",
    incorrect_answers: [
      "Aldous Huxley",
      "Ernest Hemingway",
      "Ray Bradbury",
      "George Orwell"
    ]
  },
  {
    question: "Which of the following authors was not born in England? ",
    correct_answer: "Arthur Conan Doyle",
    incorrect_answers: [
      "Graham Greene",
      "H G Wells",
      "Arthur Conan Doyle",
      "Arthur C Clarke"
    ]
  },
  {
    question: "Who wrote the A Song of Ice And  fantasy novel series?",
    correct_answer: "George R. R. Martin",
    incorrect_answers: [
      "George Lucas",
      "George Orwell",
      "George R. R. Martin",
      "George Eliot"
    ]
  },
  {
    question: "What book series published by Jim Butcher follows a wizard in modern day Chicago?",
    correct_answer: "The Dresden Files",
    incorrect_answers: [
      "A Hat in Time",
      "The Cinder Spires",
      "My Life as a Teenage Wizard",
      "The Dresden Files"
    ]
  },
  {
    question: "By what nickname is Jack Dawkins known in the Charles Dickens novel, Oliver Twist?",
    correct_answer: "The Artful Dodger",
    incorrect_answers: [
      "The Artful Dodger",
      "Fagin",
      "Bull&rsquo;s-eye",
      "Mr. Fang"
    ]
  }
]

export const gk=[
  {
    question: "Which of these cities does NOT have a United States Minting location?",
    correct_answer: "St. Louis, MO",
    incorrect_answers: [
      "San Fransisco, CA",
      "St. Louis, MO",
      "Philidelphia, PA",
      "West Point, NY"
    ]
  },
  {
    question: "What is the romanized Arabic word for moon?",
    correct_answer: "Qamar",
    incorrect_answers: [
      "Najma",
      "Kawkab",
      "Shams",
      "Qamar"
    ]
  },
  {
    question: "Which product did Nokia, the telecommunications company, originally sell?",
    correct_answer: "Paper",
    incorrect_answers: [
      "Phones",
      "Computers",
      "Paper",
      "Processors"
    ]
  },
  {
    question: "Which of the following chemicals are found in eggplant seeds?",
    correct_answer: "Nicotine",
    incorrect_answers: [
      "Nicotine",
      "Mescaline",
      "Cyanide",
      "Psilocybin"
    ]
  },
  {
    question: "Which of the following languages does NOT use gender as a part of its grammar?",
    correct_answer: "Turkish",
    incorrect_answers: [
      "German",
      "Danish",
      "Polish",
      "Turkish"
    ]
  }
]


export const film=[
  {
    question: "In what year was the first Transformers movie released?",
    correct_answer: "1986",
    incorrect_answers: [
      "2007",
      "1984",
      "1986",
      "2009"
    ]
  },
  {
    question: "What year did the James Cameron film Titanic come out in theaters?",
    correct_answer: "1997",
    incorrect_answers: [
      "1996",
      "1997",
      "1998",
      "1999"
    ]
  },
  {
    question: "What is the birth name of Michael Keaton?",
    correct_answer: "Michael Douglas",
    incorrect_answers: [
      "Michael Fox",
      "Michael Richards",
      "Michael Kane",
      "Michael Douglas"
    ]
  },
  {
    question: "Brendan Fraser starred in the following movies, except which one?",
    correct_answer: "Titanic",
    incorrect_answers: [
      "Titanic",
      "Monkeybone",
      "Encino Man",
      "Mrs. Winterbourne"
    ]
  },
  {
    question: "Which famous singer was portrayed by actor Kevin Spacey in the 2004 biographical film Beyond the Sea?",
    correct_answer: "Bobby Darin",
    incorrect_answers: [
      "Louis Armstrong",
      "Frank Sinatra",
      "Bobby Darin",
      "Dean Martin"
    ]
  }
]


export const music=[
  {
    question: "74-75 is a 1993 single from the album Ring by what American band?",
    correct_answer: "The Connells",
    incorrect_answers: [
      "R.E.M.",
      "The Ocean Blue",
      "The Bangles",
      "The Connells"
    ]
  },
  {
    question: "What's the most common time signature for rock songs?",
    correct_answer: "4/4",
    incorrect_answers: [
      "1/2",
      "8/12",
      "4/4",
      "2/4"
    ]
  },
  {
    question: "Which country does the power metal band Sabaton originate from?",
    correct_answer: "Sweden",
    incorrect_answers: [
      "Sweden",
      "Germany",
      "United States",
      "Finland"
    ]
  },
  {
    question: "What is the opening track on Lorde's Pure Heroine?",
    correct_answer: "Tennis Court",
    incorrect_answers: [
      "Team",
      "Royals",
      "Tennis Court",
      "400 Lux"
    ]
  },
  {
    question: "Which of these is NOT the name of an album released by American rapper Viper?",
    correct_answer: "The Life of Pablo",
    incorrect_answers: [
      "Kill Urself My Man",
      "The Life of Pablo",
      "You'll Cowards Don't Even Smoke Crack",
      "Yo Wife Handcuffin Me"
    ]
  }
]


export const games=[
  {
    question: "Where does The Legend of Zelda: Majora's Mask take place?",
    correct_answer: "Termina",
    incorrect_answers: [
      "Hyrule",
      "Gysahl",
      "Besaid",
      "Termina"
    ]
  },
  {
    question: "What is the name of the creature that the main character befriends in The Last Guardian?",
    correct_answer: "Trico",
    incorrect_answers: [
      "Nico",
      "Wolf",
      "Trico",
      "Andazi"
    ]
  },
  {
    question: "In which Call of Duty&quot; game are the Apothicons introduced in the Zombies mode?",
    correct_answer: "Call Of Duty: Black Ops III",
    incorrect_answers: [
      "Call Of Duty: Black Ops",
      "Call Of Duty: World At War",
      "Call Of Duty: Black Ops III",
      "Call Of Duty: Black Ops II"
    ]
  },
  {
    question: "Which of these roles in Town of Salem is mafia?",
    correct_answer: "Disguiser",
    incorrect_answers: [
      "Disguiser",
      "Escort",
      "Lookout",
      "Transporter"
    ]
  },
  {
    question: "The creator of the Touhou Project series is:",
    correct_answer: "ZUN",
    incorrect_answers: [
      "SUN",
      "RUN",
      "ZUN",
      "PUN"
    ]
  }
]


export const math=[
  {
    question: "How many sides does a heptagon have?",
    correct_answer: "7",
    incorrect_answers: [
      "8",
      "6",
      "7",
      "5"
    ]
  },
  {
    question: "What is the symbol for Displacement?",
    correct_answer: "Delta r",
    incorrect_answers: [
      "dr",
      "Dp",
      "Delta r",
      "r"
    ]
  },
  {
    question: "What is the correct order of operations for solving equations?",
    correct_answer: "Parentheses, Exponents, Multiplication, Division, Addition, Subtraction",
    incorrect_answers: [
      "Addition, Multiplication, Division, Subtraction, Addition, Parentheses",
      "Parentheses, Exponents, Addition, Substraction, Multiplication, Division",
      "The order in which the operations are written.",
      "Parentheses, Exponents, Multiplication, Division, Addition, Subtraction"
    ]
  },
  {
    question: "In Roman Numerals, what does XL equate to?",
    correct_answer: "40",
    incorrect_answers: [
      "40",
      "60",
      "15",
      "90"
    ]
  },
  {
    question: "What prime number comes next after 19?",
    correct_answer: "23",
    incorrect_answers: [
      "25",
      "21",
      "23",
      "27"
    ]
  }
]


export const comp=[
  {
    question: "The programming language Swift was created to replace what other programming language?",
    correct_answer: "Objective-C",
    incorrect_answers: [
      "C#",
      "Ruby",
      "Objective-C",
      "C++"
    ]
  },
  {
    question: "Which computer hardware device provides an interface for all other connected devices to communicate?",
    correct_answer: "Motherboard",
    incorrect_answers: [
      "Central Processing Unit",
      "Motherboard",
      "Hard Disk Drive",
      "Random Access Memory"
    ]
  },
  {
    question: "How many kilobytes in one gigabyte (in decimal)?",
    correct_answer: "1000000",
    incorrect_answers: [
      "1000000",
      "1024",
      "1000",
      "1048576"
    ]
  },
  {
    question: "What does the computer software acronym JVM stand for?",
    correct_answer: "Java Virtual Machine",
    incorrect_answers: [
      "Java Vendor Machine",
      "Java Visual Machine",
      "Java Virtual Machine",
      "Just Virtual Machine"
    ]
  },
  {
    question: "In computing, what does MIDI stand for?",
    correct_answer: "Musical Instrument Digital Interface",
    incorrect_answers: [
      "Musical Interface of Digital Instruments",
      "Musical Instrument Digital Interface",
      "Modular Interface of Digital Instruments",
      "Musical Instrument Data Interface"
    ]
  }
]


export const mythology=[
  {
    question: "Which figure from Greek mythology traveled to the underworld to return his wife Eurydice to the land of the living?",
    correct_answer: "Orpheus",
    incorrect_answers: [
      "Hercules",
      "Perseus",
      "Orpheus",
      "Daedalus"
    ]
  },
  {
    question: "How many heads does Cerberus have?",
    correct_answer: "3",
    incorrect_answers: [
      "2",
      "1",
      "3",
      "5"
    ]
  },
  {
    question: "The Nike apparel and footwear brand takes it's name from the Greek goddess of what?",
    correct_answer: "Victory",
    incorrect_answers: [
      "Courage",
      "Strength",
      "Honor",
      "Victory"
    ]
  },
  {
    question: "In most traditions, who was the wife of Zeus?",
    correct_answer: "Hera",
    incorrect_answers: [
      "Aphrodite",
      "Athena",
      "Hera",
      "Hestia"
    ]
  },
  {
    question: "This Greek goddesss name was chosen for the dwarf planet responsible for discord on Plutos classification amongst astronomers.",
    correct_answer: "Eris",
    incorrect_answers: [
      "Charon",
      "Eris",
      "Ceres",
      "Dysnomia"
    ]
  }
]


export const geography=[
  {
    question: "What is the capital of Indonesia?",
    correct_answer: "Jakarta",
    incorrect_answers: [
      "Bandung",
      "Medan",
      "Palembang",
      "Jakarta"
    ]
  },
  {
    question: "Which of these African countries list Spanish as an official language?",
    correct_answer: "Equatorial Guinea",
    incorrect_answers: [
      "Guinea",
      "Equatorial Guinea",
      "Cameroon",
      "Angola"
    ]
  },
  {
    question: "What is the Capital of the United States?",
    correct_answer: "Washington, D.C.",
    incorrect_answers: [
      "Los Angelas, CA",
      "Washington, D.C.",
      "New York City, NY",
      "Houston, TX"
    ]
  },
  {
    question: "Which UK country features a dragon on their flag?",
    correct_answer: "Wales",
    incorrect_answers: [
      "England",
      "Wales",
      "North Ireland",
      "Scotland"
    ]
  },
  {
    question: "Which of the following European languages is classified as a language isolate?",
    correct_answer: "Basque",
    incorrect_answers: [
      "Galician",
      "Maltese",
      "Hungarian",
      "Basque"
    ]
  }
]

export const art=[
  {
    question: "Who painted &quot;The Starry Night?",
    correct_answer: "Vincent van Gogh",
    incorrect_answers: [
      "Vincent van Gogh",
      "Edvard Munch",
      "Pablo Picasso",
      "Claude Monet"
    ]
  },
  {
    question: "Who painted the Sistine Chapel?",
    correct_answer: "Michelangelo",
    incorrect_answers: [
      "Leonardo da Vinci",
      "Pablo Picasso",
      "Michelangelo",
      "Raphael"
    ]
  },
  {
    question: "Who painted the biblical fresco The Creation of Adam?",
    correct_answer: "Michelangelo",
    incorrect_answers: [
      "Leonardo da Vinci",
      "Michelangelo",
      "Caravaggio",
      "Rembrandt"
    ]
  },
  {
    question: "Which painting was not made by Vincent Van Gogh?",
    correct_answer: "The Ninth Wave",
    incorrect_answers: [
      "Cafe Terrace at Night",
      "Bedroom In Arles",
      "The Ninth Wave",
      "Starry Night"
    ]
  },
  {
    question: "Who painted The Starry Night?",
    correct_answer: "Vincent van Gogh",
    incorrect_answers: [
      "Vincent van Gogh",
      "Pablo Picasso",
      "Leonardo da Vinci",
      "Michelangelo"
    ]
  }
]


export const cartoon=[
  {
    question: "In the show Steven Universe, who are the main two employees of The Big Donut?",
    correct_answer: "Sadie and Lars",
    incorrect_answers: [
      "Steven and James",
      "Erik and Julie",
      "Bob and May",
      "Sadie and Lars"
    ]
  },
  {
    question: "Wendy O. Koopa appeared in the Super Mario DIC Cartoons, but what was she known as?",
    correct_answer: "Kootie Pie",
    incorrect_answers: [
      "Sweetie Pie",
      "Kootie Pie",
      "Wendy Pie",
      "Honey Pie"
    ]
  },
  {
    question: "Which of these is NOT a catchphrase used by Rick Sanchez in the TV show Rick and Morty?",
    correct_answer: "Slam dunk, nothing but net!",
    incorrect_answers: [
      "Hit the sack, Jack!",
      "Rikki-Tikki-Tavi, biatch!",
      "Wubba-lubba-dub-dub!",
      "Slam dunk, nothing but net!"
    ]
  },
  {
    question: "Which of the following is not a Flintstones character?",
    correct_answer: "Lord Rockingham IX",
    incorrect_answers: [
      "Rockhead Slate",
      "Lord Rockingham IX",
      "The Great Gazoo",
      "Barney Rubble"
    ]
  },
  {
    question: "In The Simpsons, which war did Seymour Skinner serve in the USA Army as a Green Beret?",
    correct_answer: "Vietnam War",
    incorrect_answers: [
      "World War 2",
      "World War 1",
      "Vietnam War",
      "Cold War"
    ]
  }
]


export const politics=[
  {
    question: "In the show Steven Universe, who are the main two employees of The Big Donut?",
    correct_answer: "Sadie and Lars",
    incorrect_answers: [
      "Steven and James",
      "Erik and Julie",
      "Bob and May",
      "Sadie and Lars"
    ]
  },
  {
    question: "Wendy O. Koopa appeared in the Super Mario DIC Cartoons, but what was she known as?",
    correct_answer: "Kootie Pie",
    incorrect_answers: [
      "Kootie Pie",
      "Sweetie Pie",
      "Wendy Pie",
      "Honey Pie"
    ]
  },
  {
    question: "Which of these is NOT a catchphrase used by Rick Sanchez in the TV show Rick and Morty?",
    correct_answer: "Slam dunk, nothing but net!",
    incorrect_answers: [
      "Hit the sack, Jack!",
      "Rikki-Tikki-Tavi, biatch!",
      "Slam dunk, nothing but net!",
      "Wubba-lubba-dub-dub!"
    ]
  },
  {
    question: "Which of the following is not a Flintstones character?",
    correct_answer: "Lord Rockingham IX",
    incorrect_answers: [
      "Lord Rockingham IX",
      "Rockhead Slate",
      "The Great Gazoo",
      "Barney Rubble"
    ]
  },
  {
    question: "In The Simpsons, which war did Seymour Skinner serve in the USA Army as a Green Beret?",
    correct_answer: "Vietnam War",
    incorrect_answers: [
      "World War 2",
      "World War 1",
      "Vietnam War",
      "Cold War"
    ]
  }
]



export const celebrity=[
  {
    question: "Neil Hamburger is played by which comedian?",
    correct_answer: "Gregg Turkington",
    incorrect_answers: [
      "Gregg Turkington",
      "Nathan Fielder",
      "Tim Heidecker",
      "Todd Glass"
    ]
  },
  {
    question: "What was the cause of Marilyn Monroes suicide?",
    correct_answer: "Drug Overdose",
    incorrect_answers: [
      "Knife Attack",
      "House Fire",
      "Gunshot",
      "Drug Overdose"
    ]
  },
  {
    question: "Which celebrity announced his presidency in 2015?",
    correct_answer: "Kanye West",
    incorrect_answers: [
      "Donald Trump",
      "Kanye West",
      "Leonardo DiCaprio",
      "Miley Cyrus"
    ]
  },
  {
    question: "By which name is Ramon Estevez better known as?",
    correct_answer: "Martin Sheen",
    incorrect_answers: [
      "Charlie Sheen",
      "Ramon Sheen",
      "Martin Sheen",
      "Emilio Estevez"
    ]
  },
  {
    question: "Which actress married Michael Douglas in 2000?",
    correct_answer: "Catherine Zeta-Jones",
    incorrect_answers: [
      "Ruth Jones",
      "Pam Ferris",
      "Catherine Zeta-Jones",
      "Sara Sugarman"
    ]
  }
]


export const gadgets=[
  {
    question: "Which of the following is not a type of computer mouse?",
    correct_answer: "Smoothie mouse",
    incorrect_answers: [
      "Drum mouse",
      "Smoothie mouse",
      "Trackball mouse",
      "Optical mouse"
    ]
  },
  {
    question: "Which buzzword did Apple Inc. use to describe their removal of the headphone jack?",
    correct_answer: "Courage",
    incorrect_answers: [
      "Innovation",
      "Revolution",
      "Courage",
      "Bravery"
    ]
  },
  {
    question: "What does SSD stand for in the context of computer storage?",
    correct_answer: " Solid State Drive",
    incorrect_answers: [
      "Software Storage Device",
      "Super Speed Data",
      "Secure System Disk",
      " Solid State Drive"
    ]
  },
  {
    question: "What does GPS stand for?",
    correct_answer: "Global Positioning System",
    incorrect_answers: [
      "Global Personal System",
      "Global Positioning System",
      "General Positioning System",
      "General Personal Satellite"
    ]
  },
  {
    question: "Which gaming console is developed by Sony?",
    correct_answer: "PlayStation",
    incorrect_answers: [
      "PlayStation",
      "Xbox",
      "Atari",
      "Nintendo Switch"
    ]
  }
]
export const scnature=[
  {
    question: "What is the chemical makeup of water?",
    correct_answer: "H20",
    incorrect_answers: [
      "C12H6O2",
      "CO2",
      "H20",
      "H"
    ]
  },
  {
    question: "The asteroid belt is located between which two planets?",
    correct_answer: "Mars and Jupiter",
    incorrect_answers: [
      "Jupiter and Saturn",
      "Mercury and Venus",
      "Earth and Mars",
      "Mars and Jupiter"
    ]
  },
  {
    question: "What is the atomic mass of Carbon?",
    correct_answer: "12",
    incorrect_answers: [
      "14",
      "16",
      "12",
      "10"
    ]
  },
  {
    question: "What is the speed of light in a vacuum?",
    correct_answer: "299,792,458 m/s",
    incorrect_answers: [
      "50,461 m/s",
      "299,792,458 m/s",
      "308,215,043 m/s",
      "751,665,014,151 m/s"
    ]
  },
  {
    question: "What is the primary addictive substance found in tobacco?",
    correct_answer: "Nicotine",
    incorrect_answers: [
      "Cathinone",
      "Ephedrine",
      "Glaucine",
      "Nicotine"
    ]
  }
]
export const vehicles=[
  {
    question: "What UK Train does NOT go over 125MPH?",
    correct_answer: "Sprinter",
    incorrect_answers: [
      "Class 43",
      "Sprinter",
      "Javelin",
      "Pendolino"
    ]
  },
  {
    question: "Jaguar Cars was previously owned by which car manfacturer?",
    correct_answer: "Ford",
    incorrect_answers: [
      "Chrysler",
      "General Motors",
      "Ford",
      "Fiat"
    ]
  },
  {
    question: "What is the name of Nissan's most popular electric car?",
    correct_answer: "Leaf",
    incorrect_answers: [
      "Tree",
      "Deer",
      "Roots",
      "Leaf"
    ]
  },
  {
    question: "Which of these companies does NOT manufacture motorcycles?",
    correct_answer: "Toyota",
    incorrect_answers: [
      "Honda",
      "Toyota",
      "Kawasaki",
      "Yamaha"
    ]
  },
  {
    question: "What is the fastest road legal car in the world?",
    correct_answer: "Koenigsegg Agera RS",
    incorrect_answers: [
      "Hennessy Venom GT",
      "Bugatti Veyron Super Sport",
      "Koenigsegg Agera RS",
      "Pagani Huayra BC"
    ]
  }
]
export const history=[
  {
    question: "These two countries held a commonwealth from the 16th to 18th century.",
    correct_answer: "Poland and Lithuania",
    incorrect_answers: [
      "Hutu and Rwanda",
      "North Korea and South Korea",
      "Bangladesh and Bhutan",
      "Poland and Lithuania"
    ]
  },
  {
    question: "Who was among those killed in the 2010 Smolensk, Russia plane crash tragedy?",
    correct_answer: "The Polish President",
    incorrect_answers: [
      "Pope John Paul II",
      "Bang-Ding Ow",
      "The Polish President",
      "Albert Putin"
    ]
  },
  {
    question: "Who was the first American in space?",
    correct_answer: "Alan Shephard",
    incorrect_answers: [
      "Alan Shephard",
      "Neil Armstrong",
      "John Glenn",
      "Jim Lovell"
    ]
  },
  {
    question: "Who was the Prime Minister of Japan when Japan declared war on the US?",
    correct_answer: "Hideki Tojo",
    incorrect_answers: [
      "Michinomiya Hirohito",
      "Isoroku Yamamoto",
      "Hideki Tojo",
      "Fumimaro Konoe"
    ]
  },
  {
    question: "Which modern country is known as The Graveyard of Empires?",
    correct_answer: "Afghanistan",
    incorrect_answers: [
      "Afghanistan",
      "China",
      "Iraq",
      "Russia"
    ]
  }
]
